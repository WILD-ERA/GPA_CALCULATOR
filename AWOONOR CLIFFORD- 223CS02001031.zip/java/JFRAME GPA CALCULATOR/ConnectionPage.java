import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ConnectionPage extends JFrame {

    private static final String FILE_NAME = "gpa_records.txt";

    public ConnectionPage() {
        // Set up the JFrame
        setTitle("GPA Records System - Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        // Create input fields
        JLabel nameLabel = new JLabel("Student Name:");
        JTextField nameField = new JTextField();

        JLabel idLabel = new JLabel("Student ID:");
        JTextField idField = new JTextField();

        JLabel gpaLabel = new JLabel("GPA:");
        JTextField gpaField = new JTextField();

        JButton loginButton = new JButton("Login");

        // Add components to the JFrame
        add(nameLabel);
        add(nameField);
        add(idLabel);
        add(idField);
        add(gpaLabel);
        add(gpaField);
        add(new JLabel()); // Empty space
        add(loginButton);

        // Add action listener to the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String studentName = nameField.getText();
                String studentId = idField.getText();
                String gpa = gpaField.getText();

                if (studentName.isEmpty() || studentId.isEmpty() || gpa.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String record = "Name: " + studentName + ", ID: " + studentId + ", GPA: " + gpa;
                saveRecordToFile(record);

                JOptionPane.showMessageDialog(null, "Record saved successfully! Redirecting to GPA Calculator...");

                // Navigate to GPA Calculator page
                dispose(); // Close the current window
                new GPA_Calculator(); // Open the GPA Calculator page
            }
        });

        setVisible(true);
    }

    private void saveRecordToFile(String record) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(record);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while saving the record: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new ConnectionPage();
    }
}